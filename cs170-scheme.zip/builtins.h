#ifndef __BUILTINS_H__
#define __BUILTINS_H__

#include "internal_rep.h"
#include "environment.h"

void add_builtins(struct s_env *env);

#endif